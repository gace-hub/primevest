/* PrimeVest – Fully Static (localStorage) Version
   Works on GitHub Pages, Netlify, Vercel – no database needed
*/

const STORAGE_KEYS = {
    users: 'primevest_users',
    currentUser: 'primevest_current_user',
    investments: 'primevest_investments',
    transactions: 'primevest_transactions'
};

// ---------- Plans (hardcoded) ----------
const PLANS = [
    { id: 1, name: 'Starter Plan', description: 'Perfect for beginners. Low risk, steady returns.', min_amount: 50, max_amount: 499, roi_percent: 3, duration_days: 7 },
    { id: 2, name: 'Growth Plan', description: 'Balanced growth with attractive returns. Most popular.', min_amount: 500, max_amount: 4999, roi_percent: 8, duration_days: 14 },
    { id: 3, name: 'Premium Plan', description: 'Higher returns for serious investors.', min_amount: 5000, max_amount: 24999, roi_percent: 15, duration_days: 30 },
    { id: 4, name: 'Elite Plan', description: 'Maximum returns for high-net-worth clients.', min_amount: 25000, max_amount: 100000, roi_percent: 25, duration_days: 60 }
];

// ---------- Helpers ----------
function formatMoney(amount) {
    return '$' + Number(amount || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2, 9);
}

function getUsers() {
    return JSON.parse(localStorage.getItem(STORAGE_KEYS.users) || '[]');
}

function saveUsers(users) {
    localStorage.setItem(STORAGE_KEYS.users, JSON.stringify(users));
}

function getCurrentUser() {
    const id = localStorage.getItem(STORAGE_KEYS.currentUser);
    if (!id) return null;
    return getUsers().find(u => u.id === id) || null;
}

function setCurrentUser(userId) {
    if (userId) localStorage.setItem(STORAGE_KEYS.currentUser, userId);
    else localStorage.removeItem(STORAGE_KEYS.currentUser);
}

function isLoggedIn() {
    return !!getCurrentUser();
}

function getInvestments() {
    return JSON.parse(localStorage.getItem(STORAGE_KEYS.investments) || '[]');
}

function saveInvestments(list) {
    localStorage.setItem(STORAGE_KEYS.investments, JSON.stringify(list));
}

function getUserInvestments(userId) {
    return getInvestments().filter(i => i.user_id === userId);
}

function getTransactions() {
    return JSON.parse(localStorage.getItem(STORAGE_KEYS.transactions) || '[]');
}

function saveTransactions(list) {
    localStorage.setItem(STORAGE_KEYS.transactions, JSON.stringify(list));
}

function getUserTransactions(userId) {
    return getTransactions()
        .filter(t => t.user_id === userId)
        .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
}

function addTransaction(userId, type, amount, description) {
    const txs = getTransactions();
    txs.push({
        id: generateId(),
        user_id: userId,
        type,
        amount: Number(amount),
        description,
        status: 'completed',
        created_at: new Date().toISOString()
    });
    saveTransactions(txs);
}

function updateUserBalance(userId, newBalance) {
    const users = getUsers();
    const idx = users.findIndex(u => u.id === userId);
    if (idx !== -1) {
        users[idx].balance = Number(newBalance);
        saveUsers(users);
    }
}

// Simple hash for demo (not real security – client side only)
function simpleHash(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
        const char = str.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash;
    }
    return 'h' + Math.abs(hash).toString(16);
}

// ---------- Auth ----------
function register(username, email, password) {
    const users = getUsers();
    if (users.find(u => u.username.toLowerCase() === username.toLowerCase())) {
        return { success: false, message: 'Username already taken' };
    }
    if (users.find(u => u.email.toLowerCase() === email.toLowerCase())) {
        return { success: false, message: 'Email already registered' };
    }
    if (password.length < 6) {
        return { success: false, message: 'Password must be at least 6 characters' };
    }

    const user = {
        id: generateId(),
        username: username.trim(),
        email: email.trim().toLowerCase(),
        password: simpleHash(password),
        balance: 0,
        created_at: new Date().toISOString()
    };
    users.push(user);
    saveUsers(users);
    setCurrentUser(user.id);
    return { success: true, user };
}

function login(usernameOrEmail, password) {
    const users = getUsers();
    const hash = simpleHash(password);
    const user = users.find(u =>
        (u.username.toLowerCase() === usernameOrEmail.toLowerCase() ||
         u.email.toLowerCase() === usernameOrEmail.toLowerCase()) &&
        u.password === hash
    );
    if (!user) return { success: false, message: 'Invalid username/email or password' };
    setCurrentUser(user.id);
    return { success: true, user };
}

function logout() {
    setCurrentUser(null);
    window.location.href = 'index.html';
}

// ---------- Business logic ----------
function deposit(amount) {
    const user = getCurrentUser();
    if (!user) return { success: false, message: 'Please login first' };
    amount = Number(amount);
    if (isNaN(amount) || amount <= 0) return { success: false, message: 'Enter a valid amount' };

    const newBalance = user.balance + amount;
    updateUserBalance(user.id, newBalance);
    addTransaction(user.id, 'deposit', amount, 'Virtual deposit');
    return { success: true, message: `Successfully deposited ${formatMoney(amount)}` };
}

function withdraw(amount) {
    const user = getCurrentUser();
    if (!user) return { success: false, message: 'Please login first' };
    amount = Number(amount);
    if (isNaN(amount) || amount <= 0) return { success: false, message: 'Enter a valid amount' };
    if (amount > user.balance) return { success: false, message: 'Insufficient balance' };

    const newBalance = user.balance - amount;
    updateUserBalance(user.id, newBalance);
    addTransaction(user.id, 'withdrawal', amount, 'Virtual withdrawal');
    return { success: true, message: `Successfully withdrew ${formatMoney(amount)}` };
}

function invest(planId, amount) {
    const user = getCurrentUser();
    if (!user) return { success: false, message: 'Please login first' };

    const plan = PLANS.find(p => p.id === Number(planId));
    if (!plan) return { success: false, message: 'Invalid plan' };

    amount = Number(amount);
    if (isNaN(amount) || amount < plan.min_amount || amount > plan.max_amount) {
        return { success: false, message: `Amount must be between ${formatMoney(plan.min_amount)} and ${formatMoney(plan.max_amount)}` };
    }
    if (amount > user.balance) return { success: false, message: 'Insufficient balance' };

    const expectedProfit = amount * (plan.roi_percent / 100);
    const start = new Date();
    const end = new Date(start);
    end.setDate(end.getDate() + plan.duration_days);

    const investment = {
        id: generateId(),
        user_id: user.id,
        plan_id: plan.id,
        plan_name: plan.name,
        amount,
        expected_profit: expectedProfit,
        start_date: start.toISOString(),
        end_date: end.toISOString(),
        status: 'active',
        created_at: start.toISOString()
    };

    const investments = getInvestments();
    investments.push(investment);
    saveInvestments(investments);

    updateUserBalance(user.id, user.balance - amount);
    addTransaction(user.id, 'investment', amount, `Invested in ${plan.name}`);

    return { success: true, message: `Successfully invested ${formatMoney(amount)} in ${plan.name}` };
}

// ---------- UI Helpers ----------
function renderNavbar() {
    const user = getCurrentUser();
    const nav = document.getElementById('navbar');
    if (!nav) return;

    let links = '';
    let right = '';

    if (user) {
        links = `
            <li class="nav-item"><a class="nav-link" href="dashboard.html">Dashboard</a></li>
            <li class="nav-item"><a class="nav-link" href="plans.html">Investment Plans</a></li>
            <li class="nav-item"><a class="nav-link" href="deposit.html">Deposit</a></li>
            <li class="nav-item"><a class="nav-link" href="withdraw.html">Withdraw</a></li>
        `;
        right = `
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                    <i class="bi bi-person-circle me-1"></i>
                    ${user.username}
                    <span class="badge bg-success ms-1">${formatMoney(user.balance)}</span>
                </a>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="dashboard.html">My Dashboard</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item text-danger" href="#" onclick="logout(); return false;">Logout</a></li>
                </ul>
            </li>
        `;
    } else {
        links = `
            <li class="nav-item"><a class="nav-link" href="index.html">Home</a></li>
            <li class="nav-item"><a class="nav-link" href="plans.html">Plans</a></li>
        `;
        right = `
            <li class="nav-item"><a class="nav-link" href="login.html">Login</a></li>
            <li class="nav-item"><a class="btn btn-primary btn-sm ms-2" href="register.html">Get Started</a></li>
        `;
    }

    nav.innerHTML = `
    <nav class="navbar navbar-expand-lg navbar-light bg-white border-bottom sticky-top shadow-sm">
        <div class="container">
            <a class="navbar-brand fw-bold text-primary" href="index.html">
                <i class="bi bi-graph-up-arrow me-2"></i>PrimeVest
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navMenu">
                <ul class="navbar-nav me-auto">${links}</ul>
                <ul class="navbar-nav">${right}</ul>
            </div>
        </div>
    </nav>`;
}

function renderFooter() {
    const footer = document.getElementById('footer');
    if (!footer) return;
    footer.innerHTML = `
    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container text-center">
            <p class="mb-1"><strong>PrimeVest</strong> – Demo / Educational Prototype</p>
            <p class="mb-0 small text-white-50">Fully static version • Data stored in your browser only • No real money</p>
        </div>
    </footer>`;
}

function requireAuth() {
    if (!isLoggedIn()) {
        window.location.href = 'login.html';
        return false;
    }
    return true;
}

function showAlert(containerId, message, type = 'success') {
    const el = document.getElementById(containerId);
    if (!el) return;
    el.innerHTML = `<div class="alert alert-${type} alert-dismissible fade show" role="alert">
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>`;
}

// ---------- Seed demo user if empty ----------
(function initDemo() {
    if (getUsers().length === 0) {
        const users = [{
            id: 'demo-user',
            username: 'demo',
            email: 'demo@primevest.com',
            password: simpleHash('demo123'),
            balance: 1000,
            created_at: new Date().toISOString()
        }];
        saveUsers(users);
    }
})();
