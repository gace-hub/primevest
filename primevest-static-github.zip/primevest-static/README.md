# PrimeVest – Static Version (GitHub Pages / Netlify Ready)

This is a **fully static** version of the PrimeVest investment demo.

- **No PHP**
- **No MySQL / database**
- **No backend server required**

All data (users, balances, investments, transactions) is stored in the browser using `localStorage`.

Perfect for hosting on:
- GitHub Pages
- Netlify
- Vercel
- Cloudflare Pages
- Any static host

## Features
- User registration & login (client-side)
- Dashboard with balance, investments & transaction history
- Multiple investment plans
- Virtual deposits & withdrawals
- Invest in plans
- Responsive modern UI (same design as original)

## Demo Account
- Username: `demo`
- Password: `demo123`
(Already pre-loaded with $1000 balance)

## How to Host on GitHub Pages

1. Create a new GitHub repository
2. Upload **all files** from this folder to the root of the repository
3. Go to **Settings → Pages**
4. Source: Deploy from branch → `main` → `/ (root)`
5. Save → your site will be live at `https://yourusername.github.io/repo-name`

## How to Host on Netlify

1. Drag & drop this entire folder onto https://app.netlify.com/drop  
   **or**
2. Connect the GitHub repo and set publish directory to `/` (root)

## Important Notes
- This is a **demo / educational** project only.
- Data lives only in the current browser. Clearing browser data or using another device resets everything.
- Passwords are lightly hashed client-side (not secure for real apps).
- No real money or real payments.

Enjoy!
